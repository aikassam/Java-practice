/**
 * @author Aiman Kassam
 * @version 1.0
 * @since 2023-02-07
 */

package labtest1;
import java.util.Arrays;

/**
 *
 * @author aiman
 * The following code is the error-free version of the source code given during the Week 5 lab period for ENGG1420
 */
public class LabTest1 {
    /**
     * Correction 1 (Line 30): Changed relational operator to be non-inclusive, as array with n elements has elements (0 - (n-1)) 
     * Correction 2 (Line 34): Flipped relational operator, as in its current state, it is sorting for highest to lowest value
     * Correction 3 (Line 51): Adjusted element of array to (n-1), as arrays of length "n" have elements 0 to (n-1).
     * Correction 4 (Line 57): Flipped relational operators for each if-statement, as they are currently sorting for highest-to-lowest value
     * Correction 5(Line 88): Adjusted for-loop's initial value, condition, and increment to accommodate the purpose of both for loops, then removed the second.
     * 
     */
    
    void sortFunction4(int unsorted[])
    {
        int index = 0;
        int n = unsorted.length;
        /*Changed relational operator to be non-inclusive, as array with n elements has elements (0 - (n-1))*/
        while (index < n) { 
            if (index == 0)
                index++; 
            /*Flipped relational operator, as in its current state, it is sorting for highest to lowest value*/
            if (unsorted[index - 1] < unsorted[index]) 
                index++;
            else {
                int temp = 0;
                temp = unsorted[index];
                unsorted[index] = unsorted[index - 1];
                unsorted[index - 1] = temp;
                index--;
            }
        }
    }
 
    void sortFunction5(int unsorted[]) 
    {
        int n = unsorted.length;
        int min = unsorted[0];
        /** Adjusted element of array to (n-1), as arrays of length "n" have elements 0 to (n-1).*/
        int max = unsorted[n-1];
        int range, i, j, index;
        
        for(int a=0; a<n; a++)
        {
            /**Flipped relational operators for each if-statement, as they are currently sorting for highest-to-lowest value*/
            if(unsorted[a] > max) 
                max = unsorted[a];
            if(unsorted[a] < min) 
                min = unsorted[a];
        }
 
        range = max - min + 1;
        int[] phole = new int[range];
        Arrays.fill(phole, 0);
 
        for(i = 0; i<n; i++)
            phole[unsorted[i] - min]++;
 
         
        index = 0;
 
        for(j = 0; j<range; j++)
            while(phole[j]-->0)
                unsorted[index++]=j+min;
    }
     
    void sortFunction6(int unsorted[]) 
    {
        boolean isSorted = false;
        int n = unsorted.length;
        while (!isSorted)
        {
            isSorted = true;
            int temp =0;
 
            /** Adjusted for-loop's initial value, condition, and increment to accommodate the purpose of both for loops, then removed the second.*/
            for (int i=0; i<n-1; i++)
            {
                if (unsorted[i + 1] < unsorted[i]) 
                {
                    temp = unsorted[i];
                    unsorted[i] = unsorted[i+1];
                    unsorted[i+1] = temp;
                    isSorted = false;
                }
            }
        }
    }
     
    void printArray(int arr[])
    {
        int n = arr.length;
        for (int i=0; i<n; ++i)
            System.out.print(arr[i]+" ");
        System.out.println();
    }
 
    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        LabTest1 obj = new LabTest1();
        
        int unsorted4[] = {64,25,12,22,11};
        obj.sortFunction4(unsorted4);
        System.out.println("Sorted array4 : ");
        obj.printArray(unsorted4);
        
        
        int unsorted5[] = {64,25,12,22,11};
        obj.sortFunction5(unsorted5);
        System.out.println("Sorted array5 : ");
        obj.printArray(unsorted5);
        
        int unsorted6[] = {64,25,12,22,11};
        obj.sortFunction6(unsorted6);
        System.out.println("Sorted array6 : ");
        obj.printArray(unsorted6);
       
    }
    
}
